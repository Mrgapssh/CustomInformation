#
# TABLE STRUCTURE FOR: archivos
#

DROP TABLE IF EXISTS archivos;

CREATE TABLE `archivos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `nombrearchivo` varchar(200) NOT NULL,
  `archivo` varchar(200) NOT NULL,
  `descripcion` text NOT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO archivos (`id`, `user_id`, `nombrearchivo`, `archivo`, `descripcion`, `fecha`) VALUES ('2', '9', 'Prueba', '674b689bbf77afa40865f0292e816c9b.jpg', '&lt;p&gt;xx&lt;/p&gt;', '2016-03-05 10:29:50');
INSERT INTO archivos (`id`, `user_id`, `nombrearchivo`, `archivo`, `descripcion`, `fecha`) VALUES ('4', '10', 'xxx', 'd2733cd987b5eebdd675e9110c86d7cd.jpg', '&lt;p&gt;xxx&lt;/p&gt;', '2016-03-18 18:32:52');
INSERT INTO archivos (`id`, `user_id`, `nombrearchivo`, `archivo`, `descripcion`, `fecha`) VALUES ('5', '11', 'acta', '75ceddec888128081c9d8b8499b8240c.docx', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', '2016-08-26 11:24:34');


#
# TABLE STRUCTURE FOR: core
#

DROP TABLE IF EXISTS core;

CREATE TABLE `core` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` char(10) NOT NULL DEFAULT '0',
  `domain` varchar(65) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `tax` varchar(5) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `autobackup` int(11) DEFAULT NULL,
  `cronjob` int(11) DEFAULT NULL,
  `last_cronjob` int(11) DEFAULT NULL,
  `last_autobackup` int(11) DEFAULT NULL,
  `invoice_terms` mediumtext,
  `company_reference` int(6) DEFAULT NULL,
  `project_reference` int(6) DEFAULT NULL,
  `invoice_reference` int(6) DEFAULT NULL,
  `subscription_reference` int(6) DEFAULT NULL,
  `ticket_reference` int(10) DEFAULT NULL,
  `date_format` varchar(20) DEFAULT NULL,
  `date_time_format` varchar(20) DEFAULT NULL,
  `invoice_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_link_mail_subject` varchar(150) DEFAULT NULL,
  `credentials_mail_subject` varchar(150) DEFAULT NULL,
  `notification_mail_subject` varchar(150) DEFAULT NULL,
  `language` varchar(150) DEFAULT NULL,
  `invoice_address` varchar(200) DEFAULT NULL,
  `invoice_city` varchar(200) DEFAULT NULL,
  `invoice_contact` varchar(200) DEFAULT NULL,
  `invoice_tel` varchar(50) DEFAULT NULL,
  `subscription_mail_subject` varchar(250) DEFAULT NULL,
  `logo` varchar(150) DEFAULT NULL,
  `template` varchar(200) DEFAULT 'blueline',
  `paypal` varchar(5) DEFAULT '1',
  `paypal_currency` varchar(200) DEFAULT 'EUR',
  `paypal_account` varchar(200) DEFAULT '',
  `invoice_logo` varchar(150) DEFAULT 'assets/blueline/img/invoice_logo.png',
  `pc` varchar(150) DEFAULT NULL,
  `vat` varchar(150) DEFAULT NULL,
  `ticket_email` varchar(250) DEFAULT NULL,
  `ticket_default_owner` int(10) DEFAULT '1',
  `ticket_default_queue` int(10) DEFAULT '1',
  `ticket_default_type` int(10) DEFAULT '1',
  `ticket_default_status` varchar(200) DEFAULT 'new',
  `ticket_config_host` varchar(250) DEFAULT NULL,
  `ticket_config_login` varchar(250) DEFAULT NULL,
  `ticket_config_pass` varchar(250) DEFAULT NULL,
  `ticket_config_port` varchar(250) DEFAULT NULL,
  `ticket_config_ssl` varchar(250) DEFAULT NULL,
  `ticket_config_email` varchar(250) DEFAULT NULL,
  `ticket_config_flags` varchar(250) DEFAULT '/notls',
  `ticket_config_search` varchar(250) DEFAULT 'UNSEEN',
  `ticket_config_timestamp` int(11) DEFAULT '0',
  `ticket_config_mailbox` varchar(250) DEFAULT NULL,
  `ticket_config_delete` int(11) DEFAULT '0',
  `ticket_config_active` int(11) DEFAULT '0',
  `ticket_config_imap` int(11) DEFAULT '1',
  `stripe` int(11) DEFAULT '0',
  `stripe_key` varchar(250) DEFAULT NULL,
  `stripe_p_key` varchar(255) DEFAULT '',
  `stripe_currency` varchar(255) DEFAULT 'USD',
  `bank_transfer` int(11) DEFAULT '0',
  `bank_transfer_text` longtext NOT NULL,
  `estimate_terms` longtext NOT NULL,
  `estimate_prefix` varchar(250) DEFAULT 'EST',
  `estimate_pdf_template` varchar(250) DEFAULT 'templates/estimate/blueline',
  `invoice_pdf_template` varchar(250) DEFAULT 'templates/invoice/blueline',
  `second_tax` varchar(5) DEFAULT '',
  `estimate_mail_subject` varchar(255) DEFAULT 'New Estimate #{estimate_id}',
  `money_format` int(20) unsigned NOT NULL DEFAULT '1',
  `money_currency_position` int(20) unsigned NOT NULL DEFAULT '1',
  `pdf_font` varchar(255) DEFAULT 'NotoSans',
  `pdf_path` int(10) unsigned NOT NULL DEFAULT '1',
  `registration` int(10) unsigned NOT NULL DEFAULT '0',
  `templateportal` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `keywords` varchar(250) NOT NULL,
  `facebook` varchar(100) NOT NULL,
  `twitter` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO core (`id`, `version`, `domain`, `email`, `company`, `tax`, `currency`, `autobackup`, `cronjob`, `last_cronjob`, `last_autobackup`, `invoice_terms`, `company_reference`, `project_reference`, `invoice_reference`, `subscription_reference`, `ticket_reference`, `date_format`, `date_time_format`, `invoice_mail_subject`, `pw_reset_mail_subject`, `pw_reset_link_mail_subject`, `credentials_mail_subject`, `notification_mail_subject`, `language`, `invoice_address`, `invoice_city`, `invoice_contact`, `invoice_tel`, `subscription_mail_subject`, `logo`, `template`, `paypal`, `paypal_currency`, `paypal_account`, `invoice_logo`, `pc`, `vat`, `ticket_email`, `ticket_default_owner`, `ticket_default_queue`, `ticket_default_type`, `ticket_default_status`, `ticket_config_host`, `ticket_config_login`, `ticket_config_pass`, `ticket_config_port`, `ticket_config_ssl`, `ticket_config_email`, `ticket_config_flags`, `ticket_config_search`, `ticket_config_timestamp`, `ticket_config_mailbox`, `ticket_config_delete`, `ticket_config_active`, `ticket_config_imap`, `stripe`, `stripe_key`, `stripe_p_key`, `stripe_currency`, `bank_transfer`, `bank_transfer_text`, `estimate_terms`, `estimate_prefix`, `estimate_pdf_template`, `invoice_pdf_template`, `second_tax`, `estimate_mail_subject`, `money_format`, `money_currency_position`, `pdf_font`, `pdf_path`, `registration`, `templateportal`, `description`, `keywords`, `facebook`, `twitter`) VALUES ('1', '2.3.3', 'www.legalitesas.com', 'contacto@legalitesas.com', 'LEGALITE SAS', '0', '$', '1', '1', '0', '0', 'Thank you for your business. We do expect payment within {due_date}, so please process this invoice within that time.', '41002', '51001', '31001', '61001', '10001', 'Y/m/d', 'g:i A', 'New Invoice', 'Password Reset', 'Password Reset', 'Login Details', 'Notification', 'spanish', 'Av. 6 N# 35 -147  ', 'CUCUTA - NORTE DE SANTANDER', 'LEGALITE SAS', '311 555 5555', 'New Subscription', 'files/media/logo3.png', 'blueline', '0', 'USD', '', 'assets/blueline/images/FC2_logo_dark.png', 'c1030dd6-2669-4435-a3d8-96002a2959b6', '', NULL, '1', '1', '1', 'new', NULL, NULL, NULL, NULL, NULL, NULL, '/notls', 'UNSEEN', '0', NULL, '0', '0', '1', '0', NULL, '', 'USD', '0', '', '', 'EST', 'templates/estimate/whitelight', 'templates/invoice/blueline', '', 'New Estimate #{estimate_id}', '1', '1', 'NotoSans', '1', '0', 'web', 'Para el GRUPO LEGALITE es una filosofía, un objetivo y un compromiso, basado en la satisfacción plena de la Organización, de sus clientes y sus usuarios. Para ello prestamos una Asistencia Profesional Integral con el mejor Recurso Humano, Capacitado y Convencido de su labor, respaldados por un estricto control de procesos, con el fin de garantizar el cumplimiento de las especificaciones del servicio, para así lograr la satisfacción del cliente y buscar un mejoramiento continuo del Sistema de Gestión de Calidad.', 'Asesor Gerencial, Asesor Jurídico, Asesor Contable', 'https://www.facebook.com', '#');


#
# TABLE STRUCTURE FOR: empresas
#

DROP TABLE IF EXISTS empresas;

CREATE TABLE `empresas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nit` int(40) NOT NULL,
  `nombre` varchar(300) DEFAULT NULL,
  `representante` varchar(300) DEFAULT NULL,
  `telefono` int(16) DEFAULT NULL,
  `direccion` int(16) DEFAULT NULL,
  `email` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO empresas (`id`, `nit`, `nombre`, `representante`, `telefono`, `direccion`, `email`) VALUES ('9', '1090', 'juan', 'camilo', '102102', '230230', 'jdj223');
INSERT INTO empresas (`id`, `nit`, `nombre`, `representante`, `telefono`, `direccion`, `email`) VALUES ('13', '0', 'sasas', 'sasa', '0', '0', 'asnasn');


#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `link` varchar(250) DEFAULT '0',
  `type` varchar(250) DEFAULT '0',
  `icon` varchar(150) DEFAULT NULL,
  `sort` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('1', 'Dashboard', 'dashboard', 'main', 'icon-th', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('9', 'Settings', 'settings', 'main', 'icon-cog', '20');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('10', 'QuickAccess', 'quickaccess', 'widget', NULL, '50');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('11', 'User Online', 'useronline', 'widget', NULL, '51');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('20', 'Usuarios', 'settings/users', 'main', 'icon-user', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('21', 'archivos', 'archivos', 'main', 'icon-file', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('22', 'backup', 'settings/backup', 'main', 'icon-briefcase', '5');


#
# TABLE STRUCTURE FOR: pw_reset
#

DROP TABLE IF EXISTS pw_reset;

CREATE TABLE `pw_reset` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) DEFAULT '0',
  `timestamp` varchar(250) DEFAULT '0',
  `token` varchar(250) DEFAULT '0',
  `user` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO pw_reset (`id`, `email`, `timestamp`, `token`, `user`) VALUES ('1', 'caicedo31@hotmail.com', '1458307726', 'bdd71004a5452cbca6a5fd2d3380a08b', '1');
INSERT INTO pw_reset (`id`, `email`, `timestamp`, `token`, `user`) VALUES ('2', 'carlossuarezquintero@gmail.com', '1458307796', '6b2c02dc91a8056712097ae413288fea', '1');
INSERT INTO pw_reset (`id`, `email`, `timestamp`, `token`, `user`) VALUES ('3', 'carlossuarezquintero@gmail.com', '1458308038', 'b0babeb0320f01d9aac93872ef9b668b', '1');
INSERT INTO pw_reset (`id`, `email`, `timestamp`, `token`, `user`) VALUES ('4', 'carlossuarezquintero@gmail.com', '1458344682', 'b095b4765a9b864e15196e82376018a5', '1');


#
# TABLE STRUCTURE FOR: quinessomos
#

DROP TABLE IF EXISTS quinessomos;

CREATE TABLE `quinessomos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `archivo` varchar(200) NOT NULL,
  `nombrearchivo` varchar(200) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `contenido` text NOT NULL,
  `estado` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO quinessomos (`id`, `archivo`, `nombrearchivo`, `nombre`, `contenido`, `estado`) VALUES ('1', '13b5a1051a9da418403f4bd31aebca8e.png', 'x', 'victor', 'hola', '');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `nit` varchar(30) NOT NULL,
  `firstname` varchar(120) DEFAULT NULL,
  `lastname` varchar(120) DEFAULT NULL,
  `hashed_password` varchar(128) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `status` enum('active','inactive','deleted') DEFAULT NULL,
  `admin` enum('0','1') DEFAULT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `userpic` varchar(250) DEFAULT 'no-pic.png',
  `title` varchar(150) NOT NULL,
  `access` varchar(150) NOT NULL DEFAULT '1,2',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  `queue` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `username`, `nit`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('9', 'Admin', '12345', 'carlosxx', 'baba', '65122050e1829fcd69a3811d784e682bb8dc3e1adaccd3d5737c38b729db5655e2eed4e26f3aa5b53e3dd69829417d1678cc9d17cc66af7f3ec4203df8061447', '', 'active', '1', '2013-01-03 03:00:00', 'no-pic.png', '', '1,20,21,22,9,10,11', '1472698275', '1472684985', '0');
INSERT INTO users (`id`, `username`, `nit`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('10', 'carlos', '', 'carlos', 'jose', '1d6e52ed78f73556e460f4c31f6b93e49913770ccb6b10107ba1346b62751d65019df2e085ced6d8c40ef779fd0552abf35e76e93279277908e5ab5b6e2f635a', 'medina@hotmail.com', 'active', '0', '2016-03-11 20:52:27', 'no-pic.png', 'Desarrollo Tecnológico', '1,9,10', '0', '1457711634', '0');
INSERT INTO users (`id`, `username`, `nit`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('11', 'victor', '123456', 'victor', 'arias', '9b38d18576b386be96b4bc5abaa442d8064b71ccf869adf84b818cfa215c298181a1699403787f1669b0c71e2276ab2adfb1e3d3c0b8fccc07ab6a11eabffec1', 'v@hotmail.com', 'deleted', '1', '2016-03-11 20:55:17', 'no-pic.png', 'Empresa', '1,21,9,10', '0', '1472228700', '0');
INSERT INTO users (`id`, `username`, `nit`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('12', 'm.sotelo', '', 'Mauricio', 'Sotelo', 'b9dd1875e48e50359e2028f1cc9605f0eaf03b0ec4e2574f345ef97e6346510a2c63c6cc4e17dae8c7916234fd739b43bc240f66c58f66abaecaf124e40b31ab', 'm.sotelo@unisimonbolivar.edu.co', 'deleted', '0', '2016-08-31 10:45:12', 'no-pic.png', 'Usuarios', '1,2', NULL, NULL, '0');
INSERT INTO users (`id`, `username`, `nit`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('13', 'a.peñaloza', '', 'arlene', 'peñaloza', '9ffbc864b05353c51f101a37d36a9921d082c00a7cab47deb14f2a4bbc7d7bed4d8afa8f454b30a71d8f6419c930ed450d9fb640d0bc1ae15b4dbccb16d3879b', 'a.penaloza@unismonboliva.edu.co', 'deleted', '0', '2016-08-31 10:46:50', 'no-pic.png', 'Usuarios', '1,2', NULL, NULL, '0');
INSERT INTO users (`id`, `username`, `nit`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('14', 'juan', '', 'camilo', 'bautista', '7f6d57cc90483837c98ca463a351a61b34716be165e14f2ff6fec8cc0ca168374edfe54e577bb75e306b1ab55f9b493f253125f69f161cee83150e4de8aaa015', 'jasj@hotmail.com', 'deleted', '1', '2016-08-31 11:42:48', 'no-pic.png', 'Coordinacion Operativa', '1,2', NULL, NULL, '0');
INSERT INTO users (`id`, `username`, `nit`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('15', 'sdd', '', 'sdsd', 'dsds', '47919138ba1b4e9f0d923f42376179d0de27a00643f00cc473c2a4ee09b517c1d3ac4db604ce86953432d21a830489588e93ab97ee9a8a9510ea14230f4ef256', 'dsd@hotmail.com', 'deleted', '1', '2016-08-31 11:47:18', 'no-pic.png', 'Emprendimieto', '1,2', NULL, NULL, '0');


